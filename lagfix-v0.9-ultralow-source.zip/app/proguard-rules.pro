# Keep Android entry points and Shizuku integration stable under R8.
-keep class com.lagfix.optimizer.MainActivity { *; }
-keep class com.lagfix.optimizer.RamJobService { *; }
-keep class com.lagfix.optimizer.JunkJobService { *; }
-keep class rikka.shizuku.** { *; }
-keepattributes *Annotation*,InnerClasses,EnclosingMethod
