package com.lagfix.optimizer

import android.app.job.JobParameters
import android.app.job.JobService
import android.os.Environment
import kotlin.concurrent.thread

/** Chay 1 lan/ngay, chi xoa file co duoi tam quen thuoc (khong dung neu chua co quyen quan ly tep). */
class JunkJobService : JobService() {
    private val junkExt = setOf("tmp", "temp", "log", "crdownload", "part")

    override fun onStartJob(params: JobParameters?): Boolean {
        thread {
            try {
                if (Environment.isExternalStorageManager()) {
                    Environment.getExternalStorageDirectory().walkTopDown()
                        .onEnter { it.name != "Android" }
                        .forEach { f ->
                            if (f.isFile && (f.extension.lowercase() in junkExt ||
                                    f.name.lowercase().contains("thumbdata") ||
                                    f.parentFile?.name == ".thumbnails")) {
                                f.delete()
                            }
                        }
                }
            } catch (_: Exception) { }
            jobFinished(params, false)
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
