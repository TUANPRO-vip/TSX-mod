package com.lagfix.optimizer

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.content.ContentResolver
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity(), Shizuku.OnRequestPermissionResultListener {
    private lateinit var root: LinearLayout
    private lateinit var infoText: TextView
    private lateinit var junkText: TextView
    private lateinit var deleteBtn: Button
    private var junk: List<File> = emptyList()

    private val animKeys = arrayOf(
        Settings.Global.WINDOW_ANIMATION_SCALE,
        Settings.Global.TRANSITION_ANIMATION_SCALE,
        Settings.Global.ANIMATOR_DURATION_SCALE
    )

    // Replace with your deployed HTTPS server URL before building the APK.
    private val apiBase = "https://YOUR-SERVER-DOMAIN"
    private var dashboardOpen = false
    @Volatile private var storedKeyCheckRunning = false

    private val prefs by lazy { getSharedPreferences("lagfix", Context.MODE_PRIVATE) }
    private val junkExt = setOf("tmp", "temp", "log", "crdownload", "part")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try { Shizuku.addRequestPermissionResultListener(this) } catch (_: Throwable) { }
        showLogin()
    }

    override fun onDestroy() {
        try { Shizuku.removeRequestPermissionResultListener(this) } catch (_: Throwable) { }
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (dashboardOpen) {
            refresh()
            checkStoredKeySilently()
        }
    }

    override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
        if (requestCode != ShizukuHelper.REQUEST_CODE) return
        runOnUiThread {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                val ok = ShizukuHelper.grantWriteSecureSettings(packageName)
                toast(if (ok) "Shizuku đã cấp quyền làm mượt máy." else "Shizuku chưa chạy được lệnh cấp quyền. Dùng cách ADB bên dưới.")
                refresh()
            } else {
                toast("Bạn chưa cho phép Shizuku.")
            }
        }
    }

    private fun showLogin() {
        dashboardOpen = false
        val page = makeRoot()
        page.addView(label("LagFix Pro", 30f, true))
        page.addView(label("Đăng nhập bằng key được cấp bởi quản trị viên", 16f, false))
        val keyInput = EditText(this).apply {
            hint = "Nhập key"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
        }
        page.addView(keyInput)
        page.addButton("Xác thực key") {
            val key = keyInput.text.toString().trim()
            if (key.isBlank()) { toast("Hãy nhập key"); return@addButton }
            validateKey(key)
        }
        page.addView(label("Bảo mật: key chỉ được xác thực qua máy chủ HTTPS; không có key chủ nhúng trong APK.", 13f, false))
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(page) })
    }

    private fun validateKey(key: String) {
        if (apiBase.contains("YOUR-SERVER-DOMAIN")) {
            toast("Chưa cấu hình máy chủ key. Hãy triển khai key-server HTTPS rồi cập nhật apiBase.")
            return
        }
        thread {
            var message = "Không kết nối được máy chủ key."
            var ok = false
            try {
                val conn = (URL("$apiBase/api/validate").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("key", key).toString().toByteArray(Charsets.UTF_8)) }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: "{}"
                val json = JSONObject(body)
                ok = conn.responseCode in 200..299 && json.optBoolean("valid", false)
                message = json.optString("message", if (ok) "Key hợp lệ" else "Key không hợp lệ hoặc đã hết hạn.")
                conn.disconnect()
            } catch (_: Exception) { }
            runOnUiThread {
                if (ok) {
                    // Do not persist an authorization flag: validate with the server on every launch.
                    prefs.edit().putBoolean("key_valid", false).putString("key", key).apply()
                    toast("Đăng nhập thành công")
                    showDashboard()
                } else toast(message)
            }
        }
    }

    private fun checkStoredKeySilently(showMessages: Boolean = false) {
        val key = prefs.getString("key", null)?.trim().orEmpty()
        if (key.isBlank() || apiBase.contains("YOUR-SERVER-DOMAIN") || storedKeyCheckRunning) {
            if (showMessages) toast(if (key.isBlank()) "Chưa lưu key đăng nhập." else "Chưa cấu hình máy chủ HTTPS.")
            return
        }
        storedKeyCheckRunning = true
        thread {
            var valid = false
            var message = "Không thể kết nối máy chủ; kiểm tra lại khi có mạng."
            var connection: HttpURLConnection? = null
            try {
                connection = URL("$apiBase/api/validate").openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json")
                connection.outputStream.use {
                    it.write(JSONObject().put("key", key).toString().toByteArray(Charsets.UTF_8))
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
                val json = JSONObject(body)
                valid = code in 200..299 && json.optBoolean("valid", false)
                message = json.optString("message", if (valid) "Key hợp lệ." else "Key không hợp lệ hoặc đã bị thu hồi.")
            } catch (_: Exception) {
                // Keep the current screen during a temporary network outage; never grant new access offline.
            } finally {
                connection?.disconnect()
                storedKeyCheckRunning = false
            }
            runOnUiThread {
                if (!valid && message != "Không thể kết nối máy chủ; kiểm tra lại khi có mạng.") {
                    dashboardOpen = false
                    prefs.edit().remove("key_valid").remove("key").apply()
                    toast("Key không còn hợp lệ. Vui lòng đăng nhập lại.")
                    showLogin()
                } else if (showMessages) {
                    toast(if (valid) "Key còn hiệu lực." else message)
                }
            }
        }
    }

    private fun showDashboard() {
        dashboardOpen = true
        val page = makeRoot()
        page.addView(label("LagFix Pro", 30f, true))
        page.addView(label("Công cụ theo dõi và tối ưu an toàn", 15f, false))
        infoText = label("", 16f, false).apply { setPadding(0, dp(16), 0, dp(8)) }
        page.addView(infoText)
        page.addButton("Làm mới thông số") { refresh() }
        page.addButton("Kiểm tra key trực tuyến") { checkStoredKeySilently(showMessages = true) }
        page.addButton("Thông tin phiên bản và bảo mật") {
            AlertDialog.Builder(this)
                .setTitle("LagFix Pro 0.9")
                .setMessage("Key được xác thực qua máy chủ khi đăng nhập và kiểm tra lại khi mở ứng dụng. Cần kết nối Internet để xác thực.\n\nLagFix chỉ hiển thị thông số và hỗ trợ các cài đặt Android được cấp quyền; không thể bảo đảm tăng FPS hoặc tự ép xung CPU/GPU.")
                .setPositiveButton("Đóng", null).show()
        }

        page.addView(label("Tối ưu trước khi chơi", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        page.addButton("Mở cài đặt pin") { openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        page.addButton("Mở tùy chọn nhà phát triển") { openSettings(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS) }
        page.addButton("Mở cài đặt lưu trữ") { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        page.addButton("Kiểm tra nhanh rồi vào game") {
            refresh()
            AlertDialog.Builder(this)
                .setTitle("Chọn phiên bản Free Fire")
                .setItems(arrayOf("Free Fire thường", "Free Fire MAX")) { _, which ->
                    if (which == 0) launchGame("com.dts.freefireth") else launchGame("com.dts.freefiremax")
                }
                .setNegativeButton("Hủy", null)
                .show()
        }
        page.addButton("Khởi chạy Free Fire thường") { launchGame("com.dts.freefireth") }
        page.addButton("Khởi chạy Free Fire MAX") { launchGame("com.dts.freefiremax") }
        page.addButton("🎮 TSX ULTRA LOW — đồ họa đơn giản") { showUltraLowGuide() }
        page.addButton("Mẹo giảm lag theo từng game") { showGraphicsTips() }
        page.addButton("Gợi ý tối ưu thủ công") { showGeneralTips() }
        page.addButton("⚡ Tối ưu toàn diện (1 chạm)") { runFullOptimize() }

        page.addView(label("Thông tin thiết bị", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        page.addButton("Xem thông tin WiFi") { showWifiInfo() }
        page.addButton("Xem thông tin pin chi tiết") { showBatteryInfo() }

        page.addView(label("Tối ưu hệ thống sâu", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        page.addView(label("Các mục này đổi cài đặt hệ thống, có thể cần cấp quyền một lần. Có thể bật/tắt lại bất kỳ lúc nào.", 13f, false))

        val swGaming = page.addSwitch("Chế độ chơi game (dọn RAM + chặn thông báo + tắt đồng bộ + giảm hiệu ứng)")
        val swAnim = page.addSwitch("Giảm hiệu ứng chuyển cảnh (0x)")
        val swVibrate = page.addSwitch("Tắt rung khi chạm")
        val swSync = page.addSwitch("Tắt đồng bộ tài khoản nền")
        val swBright = page.addSwitch("Giảm độ sáng còn 35%")
        val swSound = page.addSwitch("Tắt âm thanh chạm")
        val swAutoRam = page.addSwitch("Tự dọn RAM mỗi 15 phút")
        val swAutoJunk = page.addSwitch("Tự dọn file tạm mỗi ngày")
        val swScanApk = page.addSwitch("Quét cả file APK khi dọn file tạm")

        swGaming.setOnCheckedChangeListener { _, on -> if (!refreshing) setGamingMode(on, swAnim, swSync) }
        swAnim.setOnCheckedChangeListener { _, on -> if (!refreshing) setAnimScale(on) }
        swVibrate.setOnCheckedChangeListener { _, on -> if (!refreshing) setVibration(on) }
        swSync.setOnCheckedChangeListener { _, on -> if (!refreshing) setAutoSync(on) }
        swBright.setOnCheckedChangeListener { _, on -> if (!refreshing) setBrightness(on) }
        swSound.setOnCheckedChangeListener { _, on -> if (!refreshing) setTouchSound(on) }
        swAutoRam.setOnCheckedChangeListener { _, on -> if (!refreshing) setAutoRamJob(on) }
        swAutoJunk.setOnCheckedChangeListener { _, on -> if (!refreshing) setAutoJunkJob(on) }
        swScanApk.setOnCheckedChangeListener { _, on -> if (!refreshing) prefs.edit().putBoolean("scan_apk", on).apply() }

        this.swGaming = swGaming; this.swAnim = swAnim; this.swVibrate = swVibrate
        this.swSync = swSync; this.swBright = swBright; this.swAutoRam = swAutoRam; this.swAutoJunk = swAutoJunk
        this.swSound = swSound; this.swScanApk = swScanApk

        page.addView(label("Quyền nâng cao (Shizuku)", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        page.addView(label("Giảm hiệu ứng cần quyền WRITE_SECURE_SETTINGS. Cấp một lần qua Shizuku hoặc ADB.", 13f, false))
        page.addButton("Cấp quyền qua Shizuku") { requestShizuku() }
        page.addButton("Xem lệnh ADB (cấp tay)") { showAdbDialog() }

        page.addView(label("Dọn file tạm", 20f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        junkText = label("Chưa quét.", 15f, false)
        page.addView(junkText)
        page.addButton("Quét file tạm") { startScan() }
        page.addButton("Dọn log cũ (>7 ngày)") { cleanOldLogs() }
        deleteBtn = page.addButton("Xóa file đã chọn") { confirmDelete() }
        deleteBtn.visibility = View.GONE

        page.addButton("Đăng xuất key") {
            dashboardOpen = false
            prefs.edit().remove("key_valid").remove("key").apply()
            showLogin()
        }
        page.addView(label("Giới hạn Android: ứng dụng không thể tự ép xung CPU/GPU, giải phóng RAM của ứng dụng khác hoặc bảo đảm tăng FPS nếu không có quyền hệ thống/root. Chỉ xóa file tạm có chọn lọc.", 13f, false).apply { setPadding(0, dp(18), 0, 0) })
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0F172A"))
            isFillViewport = true
            addView(page)
        })
        refresh()
        syncSwitchStates()
    }

    // --- Cac Switch duoc giu lai de dong bo trang thai khi refresh ---
    private var swGaming: Switch? = null
    private var swAnim: Switch? = null
    private var swVibrate: Switch? = null
    private var swSync: Switch? = null
    private var swBright: Switch? = null
    private var swAutoRam: Switch? = null
    private var swAutoJunk: Switch? = null
    private var swSound: Switch? = null
    private var swScanApk: Switch? = null
    private var refreshing = false

    private fun syncSwitchStates() {
        refreshing = true
        try {
            val animOn = try { Settings.Global.getFloat(contentResolver, animKeys[0], 1f) < 0.1f } catch (_: Exception) { false }
            swAnim?.isChecked = animOn
            swVibrate?.isChecked = prefs.getBoolean("vibe_off", false)
            swSync?.isChecked = try { !ContentResolver.getMasterSyncAutomatically() } catch (_: Exception) { false }
            swBright?.isChecked = prefs.getBoolean("bright_low", false)
            swAutoRam?.isChecked = prefs.getBoolean("auto_ram", false)
            swAutoJunk?.isChecked = prefs.getBoolean("auto_junk", false)
            swGaming?.isChecked = prefs.getBoolean("gaming_mode", false)
            swSound?.isChecked = prefs.getBoolean("sound_off", false)
            swScanApk?.isChecked = prefs.getBoolean("scan_apk", false)
        } finally {
            refreshing = false
        }
    }

    private fun makeRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(36), dp(18), dp(24))
        setBackgroundColor(Color.parseColor("#0F172A"))
    }

    private fun refresh() {
        if (!::infoText.isInitialized) return
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val usedPct = 100 - (mi.availMem * 100 / mi.totalMem)
            val stat = StatFs(Environment.getDataDirectory().path)
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val thermal = when (pm.currentThermalStatus) {
                0 -> "Bình thường"; 1 -> "Hơi ấm"; 2 -> "Nóng vừa"
                3 -> "Nóng nhiều — hệ thống có thể giảm hiệu năng"; else -> "Rất nóng"
            }
            infoText.text = "RAM đang dùng: $usedPct% (còn ${fmt(mi.availMem)} / ${fmt(mi.totalMem)})\n" +
                "Bộ nhớ trống: ${fmt(stat.availableBytes)} / ${fmt(stat.totalBytes)}\n" +
                "Pin: ${if (level >= 0) level * 100 / scale else "?"}% | ${String.format("%.1f", temp)}°C\n" +
                "Nhiệt độ hệ thống: $thermal"
        } catch (_: Exception) { infoText.text = "Không đọc được một số thông số trên thiết bị này." }
    }

    private fun launchGame(packageName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else {
            toast("Chưa cài game này. Mở Google Play để cài đặt.")
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))) }
            catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))) }
        }
    }

    private fun showGeneralTips() {
        AlertDialog.Builder(this)
            .setTitle("Gợi ý tối ưu thủ công")
            .setMessage(
                "• Gỡ app ít dùng thay vì để đó chạy nền\n" +
                "• Cài đặt > Ứng dụng > từng app ít cần thiết: giới hạn dữ liệu nền\n" +
                "• Dọn bớt ảnh/video trùng, chuyển lên Google Photos hoặc đám mây\n" +
                "• Khởi động lại máy vài ngày một lần để hệ thống tự dọn RAM\n" +
                "• Luôn cập nhật app lên bản mới nhất, bản cũ thường tốn pin/RAM hơn\n" +
                "• Dùng hình nền tĩnh thay vì hình nền động để đỡ tốn RAM/pin"
            )
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun runFullOptimize() {
        toast("Đang chạy tối ưu toàn diện...")
        cleanRamNow(silent = true)
        clearCache()
        startScan()
    }

    private fun showWifiInfo() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (!wm.isWifiEnabled) {
                toast("WiFi đang tắt.")
                return
            }
            val info = wm.connectionInfo
            val rssi = info.rssi
            val quality = when {
                rssi >= -55 -> "Rất tốt"
                rssi >= -67 -> "Tốt"
                rssi >= -75 -> "Yếu"
                else -> "Rất yếu"
            }
            val ssid = info.ssid?.trim('"') ?: "?"
            val ssidDisplay = if (ssid == "<unknown ssid>") "Cần quyền vị trí để hiện tên mạng" else ssid
            val msg = "Mạng: $ssidDisplay\n" +
                "Tốc độ liên kết: ${info.linkSpeed} Mbps\n" +
                "Cường độ tín hiệu: $rssi dBm ($quality)"
            AlertDialog.Builder(this).setTitle("Thông tin WiFi").setMessage(msg)
                .setPositiveButton("Đóng", null).show()
        } catch (e: Exception) {
            toast("Không đọc được thông tin WiFi trên máy này.")
        }
    }

    private fun showBatteryInfo() {
        try {
            val bat = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val temp = (bat?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10.0
            val volt = (bat?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000.0
            val health = when (bat?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nhiệt"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Chai pin"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp"
                BatteryManager.BATTERY_HEALTH_COLD -> "Quá lạnh"
                else -> "Không xác định"
            }
            val plugged = when (bat?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1) {
                BatteryManager.BATTERY_PLUGGED_AC -> "Đang sạc (AC)"
                BatteryManager.BATTERY_PLUGGED_USB -> "Đang sạc (USB)"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Đang sạc không dây"
                else -> "Không cắm sạc"
            }
            val msg = "Mức pin: ${if (level >= 0) level * 100 / scale else "?"}%\n" +
                "Nhiệt độ: ${String.format("%.1f", temp)}°C\n" +
                "Điện áp: ${String.format("%.2f", volt)} V\n" +
                "Tình trạng: $health\n" +
                "Trạng thái: $plugged"
            AlertDialog.Builder(this).setTitle("Thông tin pin").setMessage(msg)
                .setPositiveButton("Đóng", null).show()
        } catch (e: Exception) {
            toast("Không đọc được thông tin pin.")
        }
    }

    private fun cleanOldLogs() {
        if (!Environment.isExternalStorageManager()) {
            toast("Cần cấp quyền quản lý tệp để quét log.")
            openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            return
        }
        toast("Đang tìm log cũ...")
        thread {
            val cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
            val found = ArrayList<File>()
            try {
                Environment.getExternalStorageDirectory().walkTopDown()
                    .onEnter { it.name != "Android" }
                    .forEach { f -> if (f.isFile && f.extension.lowercase() == "log" && f.lastModified() < cutoff) found.add(f) }
            } catch (_: Exception) { }
            runOnUiThread {
                if (found.isEmpty()) { toast("Không có file .log nào cũ hơn 7 ngày."); return@runOnUiThread }
                val total = found.sumOf { it.length() }
                AlertDialog.Builder(this)
                    .setTitle("Xóa log cũ?")
                    .setMessage("Tìm thấy ${found.size} file .log cũ hơn 7 ngày, khoảng ${fmt(total)}.")
                    .setPositiveButton("Xóa") { _, _ ->
                        thread {
                            var n = 0
                            for (f in found) if (f.delete()) n++
                            runOnUiThread { toast("Đã xóa $n file log cũ"); refresh() }
                        }
                    }
                    .setNegativeButton("Hủy", null)
                    .show()
            }
        }
    }

    /** Preset tư vấn đồ họa: Android không có API công khai để ép chất lượng đồ họa trong game bên thứ ba. */
    private fun showUltraLowGuide() {
        val games = arrayOf("Free Fire", "Free Fire MAX", "Cả hai — xem hướng dẫn")
        AlertDialog.Builder(this)
            .setTitle("TSX ULTRA LOW")
            .setMessage(
                "Mục tiêu: giảm tải đồ họa trên Vivo Y15s (RAM 3 GB).\n\n" +
                "Ứng dụng không sửa file game, không nhập profile NVIDIA .nip và không tự ép đồ họa xuống kiểu Roblox. Hãy áp dụng trong phần cài đặt chính thức của từng game."
            )
            .setItems(games) { _, which ->
                val title: String
                val body: String
                when (which) {
                    0 -> {
                        title = "TSX ULTRA LOW — Free Fire"
                        body = "1. Mở Free Fire > Cài đặt > Đồ họa.\n" +
                            "2. Chọn mức đồ họa thấp nhất/‘Mượt’ mà game cung cấp.\n" +
                            "3. Tắt bóng đổ và hiệu ứng bổ sung nếu có.\n" +
                            "4. Chọn FPS ổn định trước; chỉ tăng FPS nếu máy vẫn mát và game chạy ổn.\n\n" +
                            "Các tên tùy chọn có thể khác theo phiên bản game."
                    }
                    1 -> {
                        title = "TSX ULTRA LOW — Free Fire MAX"
                        body = "1. Mở Free Fire MAX > Cài đặt > Đồ họa.\n" +
                            "2. Chọn mức đồ họa thấp nhất được cung cấp.\n" +
                            "3. Tắt bóng/hiệu ứng nếu có và đóng ứng dụng nền trước khi chơi.\n" +
                            "4. Nếu vẫn giật hoặc nóng, ưu tiên FPS ổn định và giảm thời gian chơi liên tục.\n\n" +
                            "MAX nặng hơn bản thường; không thể bảo đảm giống đồ họa Roblox."
                    }
                    else -> {
                        title = "Áp dụng cho cả hai game"
                        body = "Lặp lại các bước trong mục Cài đặt > Đồ họa của từng game.\n\n" +
                            "Để máy nhẹ hơn: bật Chế độ chơi game trong LagFix, đóng app nền thủ công, để trống bộ nhớ và tránh vừa sạc vừa chơi khi máy nóng.\n\n" +
                            "Không dùng tệp .nip trên Android: chúng là profile NVIDIA cho PC."
                    }
                }
                AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(body)
                    .setPositiveButton("Mở game") { _, _ ->
                        when (which) {
                            0 -> launchGame("com.dts.freefireth")
                            1 -> launchGame("com.dts.freefiremax")
                            else -> AlertDialog.Builder(this)
                                .setTitle("Chọn game")
                                .setItems(arrayOf("Free Fire", "Free Fire MAX")) { _, pick ->
                                    launchGame(if (pick == 0) "com.dts.freefireth" else "com.dts.freefiremax")
                                }.setNegativeButton("Hủy", null).show()
                        }
                    }
                    .setNegativeButton("Đóng", null)
                    .show()
            }
            .setNegativeButton("Đóng", null)
            .show()
    }

    private fun showGraphicsTips() {
        AlertDialog.Builder(this)
            .setTitle("Mẹo giảm lag theo game")
            .setMessage(
                "Free Fire: Cài đặt > Đồ họa, để Rất mượt + độ phân giải Thấp/Vừa, tắt Bóng đổ.\n\n" +
                "Minecraft PE: Cài đặt > Video, giảm Render Distance (4-6), tắt Fancy Graphics và Beautiful Skies.\n\n" +
                "Roblox: Cài đặt > Graphics Mode: Manual, kéo Graphics Quality xuống 1-3.\n\n" +
                "Chung: bật Chế độ chơi game ở trên trước khi vào game, để máy nguội bớt nếu đang Nóng nhiều/Rất nóng."
            )
            .setPositiveButton("Đóng", null)
            .show()
    }

    // --- Giam hieu ung chuyen canh (can WRITE_SECURE_SETTINGS) ---
    private fun hasSecureSettings(): Boolean =
        checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    private fun setAnimScale(on: Boolean) {
        if (!hasSecureSettings()) {
            toast("Chưa có quyền. Bấm 'Cấp quyền qua Shizuku' hoặc xem lệnh ADB bên dưới.")
            syncSwitchStates()
            return
        }
        try {
            if (on) {
                if (!prefs.contains("anim0")) {
                    val ed = prefs.edit()
                    for (i in animKeys.indices) ed.putFloat("anim$i", Settings.Global.getFloat(contentResolver, animKeys[i], 1f))
                    ed.apply()
                }
                for (k in animKeys) Settings.Global.putFloat(contentResolver, k, 0f)
            } else {
                for (i in animKeys.indices) {
                    val old = prefs.getFloat("anim$i", 1f)
                    Settings.Global.putFloat(contentResolver, animKeys[i], old)
                }
                prefs.edit().remove("anim0").remove("anim1").remove("anim2").apply()
            }
        } catch (e: Exception) { toast("Lỗi: ${e.message}") }
    }

    // --- Rung khi cham (thuong can WRITE_SETTINGS) ---
    private fun setVibration(on: Boolean) {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettings()
            syncSwitchStates()
            return
        }
        try {
            Settings.System.putInt(contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, if (on) 0 else 1)
            prefs.edit().putBoolean("vibe_off", on).apply()
        } catch (e: Exception) { toast("Máy không cho đổi mục này") }
    }

    // --- Am thanh cham man hinh (thuong can WRITE_SETTINGS) ---
    private fun setTouchSound(on: Boolean) {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettings()
            syncSwitchStates()
            return
        }
        try {
            Settings.System.putInt(contentResolver, Settings.System.SOUND_EFFECTS_ENABLED, if (on) 0 else 1)
            prefs.edit().putBoolean("sound_off", on).apply()
        } catch (e: Exception) { toast("Máy không cho đổi mục này") }
    }

    // --- Dong bo tai khoan nen ---
    private fun setAutoSync(on: Boolean) {
        try {
            ContentResolver.setMasterSyncAutomatically(!on)
        } catch (e: Exception) { toast("Máy không cho đổi đồng bộ") }
    }

    // --- Do sang man hinh ---
    private fun setBrightness(on: Boolean) {
        if (!Settings.System.canWrite(this)) {
            requestWriteSettings()
            syncSwitchStates()
            return
        }
        try {
            if (on) {
                if (!prefs.contains("bright_old")) {
                    val cur = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
                    prefs.edit().putInt("bright_old", cur).apply()
                }
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (255 * 0.35).toInt())
            } else {
                val old = prefs.getInt("bright_old", 128)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, old)
                prefs.edit().remove("bright_old").apply()
            }
            prefs.edit().putBoolean("bright_low", on).apply()
        } catch (e: Exception) { toast("Máy không cho đổi độ sáng") }
    }

    // --- Che do choi game: gop nhieu buoc ---
    private fun setGamingMode(on: Boolean, swAnimRef: Switch, swSyncRef: Switch) {
        prefs.edit().putBoolean("gaming_mode", on).apply()
        if (on) {
            cleanRamNow(silent = true)
            setAutoSync(true); refreshing = true; swSyncRef.isChecked = true; refreshing = false
            if (hasSecureSettings()) { setAnimScale(true); refreshing = true; swAnimRef.isChecked = true; refreshing = false }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else {
                toast("Mẹo: cấp quyền 'Không làm phiền' để chặn thông báo khi chơi game")
                try { startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) } catch (_: Exception) { }
            }
            toast("Đã bật Chế độ chơi game")
        } else {
            setAutoSync(false); refreshing = true; swSyncRef.isChecked = false; refreshing = false
            if (hasSecureSettings()) { setAnimScale(false); refreshing = true; swAnimRef.isChecked = false; refreshing = false }
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            } catch (_: Exception) { }
            toast("Đã tắt Chế độ chơi game")
        }
    }

    private fun cleanRamNow(silent: Boolean = false) {
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (ai in packageManager.getInstalledApplications(0)) {
                if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
                if (ai.packageName == packageName) continue
                am.killBackgroundProcesses(ai.packageName)
            }
            if (!silent) toast("Đã dọn RAM")
        } catch (_: Exception) { }
    }

    // --- Lich tu dong qua JobScheduler ---
    private fun setAutoRamJob(on: Boolean) {
        val js = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (on) {
            val job = JobInfo.Builder(JOB_ID_RAM, ComponentName(this, RamJobService::class.java))
                .setPeriodic(15 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        } else {
            js.cancel(JOB_ID_RAM)
        }
        prefs.edit().putBoolean("auto_ram", on).apply()
    }

    private fun setAutoJunkJob(on: Boolean) {
        val js = getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (on) {
            val job = JobInfo.Builder(JOB_ID_JUNK, ComponentName(this, JunkJobService::class.java))
                .setPeriodic(24 * 60 * 60 * 1000L)
                .setPersisted(true)
                .build()
            js.schedule(job)
        } else {
            js.cancel(JOB_ID_JUNK)
        }
        prefs.edit().putBoolean("auto_junk", on).apply()
    }

    // --- Shizuku ---
    private fun requestShizuku() {
        if (!ShizukuHelper.isAvailable()) {
            toast("Chưa cài hoặc chưa chạy Shizuku. Xem lệnh ADB bên dưới thay thế.")
            return
        }
        if (ShizukuHelper.hasPermission()) {
            val ok = ShizukuHelper.grantWriteSecureSettings(packageName)
            toast(if (ok) "Đã cấp quyền làm mượt máy." else "Chưa chạy được lệnh. Dùng cách ADB bên dưới.")
            refresh()
        } else {
            try { Shizuku.requestPermission(ShizukuHelper.REQUEST_CODE) }
            catch (_: Throwable) { toast("Không gọi được Shizuku trên máy này.") }
        }
    }

    private fun showAdbDialog() {
        val cmd = "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
        AlertDialog.Builder(this)
            .setTitle("Cấp quyền qua ADB")
            .setMessage("Chạy lệnh sau trên máy tính (hoặc qua Shizuku ở trên):\n\n$cmd")
            .setPositiveButton("Đóng", null)
            .show()
    }

    private fun requestWriteSettings() {
        toast("Hãy cho phép LagFix sửa cài đặt hệ thống rồi bật lại")
        try { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }
        catch (_: Exception) { }
    }

    private fun startScan() {
        if (!Environment.isExternalStorageManager()) {
            toast("Cần cấp quyền quản lý tệp để quét thư mục chia sẻ.")
            openSettings(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            return
        }
        junkText.text = "Đang quét..."
        deleteBtn.visibility = View.GONE
        val scanApkToo = prefs.getBoolean("scan_apk", false)
        thread {
            val found = ArrayList<File>()
            val apks = ArrayList<File>()
            try {
                Environment.getExternalStorageDirectory().walkTopDown()
                    .onEnter { it.name != "Android" }
                    .forEach { f ->
                        if (!f.isFile) return@forEach
                        val ext = f.extension.lowercase()
                        if (ext in junkExt || f.name.lowercase().contains("thumbdata") || f.parentFile?.name == ".thumbnails") {
                            found.add(f)
                        } else if (scanApkToo && ext == "apk") {
                            apks.add(f)
                        }
                    }
            } catch (_: Exception) { }
            val total = found.sumOf { it.length() }
            runOnUiThread {
                junk = found
                val apkNote = if (scanApkToo && apks.isNotEmpty())
                    "\nCòn thấy ${apks.size} file .apk đã tải (${fmt(apks.sumOf { it.length() })}) — không tự xóa, bạn tự kiểm tra trong Quản lý tệp." else ""
                junkText.text = (if (found.isEmpty()) "Không tìm thấy file rác." else "Tìm thấy ${found.size} file rác, khoảng ${fmt(total)}.") + apkNote
                deleteBtn.visibility = if (found.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun confirmDelete() {
        val total = junk.sumOf { it.length() }
        AlertDialog.Builder(this).setTitle("Xóa file đã quét?")
            .setMessage("Xóa ${junk.size} file (khoảng ${fmt(total)}). Chỉ tiếp tục nếu bạn chắc chắn.")
            .setPositiveButton("Xóa") { _, _ -> deleteJunk() }
            .setNegativeButton("Hủy", null).show()
    }

    private fun deleteJunk() {
        val list = junk
        thread {
            var freed = 0L; var count = 0
            for (f in list) { val size = f.length(); if (f.delete()) { freed += size; count++ } }
            runOnUiThread {
                junk = emptyList()
                junkText.text = "Đã xóa $count file, giải phóng ${fmt(freed)}."
                deleteBtn.visibility = View.GONE
                refresh()
            }
        }
    }

    private fun openSettings(action: String, uri: Uri? = null) {
        try { startActivity(Intent(action).apply { if (uri != null) data = uri }) }
        catch (_: Exception) { toast("Thiết bị không hỗ trợ màn hình cài đặt này.") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(Color.WHITE)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun LinearLayout.addButton(text: String, onClick: () -> Unit): Button {
        val b = Button(this@MainActivity).apply { this.text = text; isAllCaps = false; setOnClickListener { onClick() } }
        addView(b); return b
    }
    private fun LinearLayout.addSwitch(text: String): Switch {
        val s = Switch(this@MainActivity).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setPadding(0, dp(10), 0, dp(10))
        }
        addView(s); return s
    }
    private fun fmt(bytes: Long): String = when {
        bytes >= 1073741824L -> String.format("%.2f GB", bytes / 1073741824.0)
        bytes >= 1048576L -> String.format("%.0f MB", bytes / 1048576.0)
        else -> String.format("%d KB", bytes / 1024)
    }

    companion object {
        const val JOB_ID_RAM = 1001
        const val JOB_ID_JUNK = 1002
    }
}
