# LagFix key server — v0.9

## Chạy thử
1. Cài Node.js 20+.
2. Trong thư mục `key-server`, chạy `npm install`.
3. Đặt một admin token dài, ngẫu nhiên:
   - Linux/macOS: `export ADMIN_TOKEN='chuoi-bi-mat-dai-ngau-nhien'`
   - Windows PowerShell: `$env:ADMIN_TOKEN='chuoi-bi-mat-dai-ngau-nhien'`
4. Chạy `npm start`, sau đó mở `http://localhost:3000`.

## Đưa lên mạng
Triển khai thư mục này lên dịch vụ Node.js có HTTPS và lưu trữ bền vững. Đặt biến môi trường `ADMIN_TOKEN`. Không dùng HTTP thường để gửi key/token. Sao lưu `keys.json`; khóa admin không đưa vào APK. Trang quản trị demo nên bổ sung đăng nhập thật, giới hạn tốc độ, nhật ký và bảo vệ CSRF trước khi dùng công khai.

## Kết nối APK
Sửa `apiBase` trong `app/src/main/java/com/lagfix/optimizer/MainActivity.kt` thành URL HTTPS máy chủ, ví dụ `https://keys.example.com`, rồi build APK lại. API:
- `POST /api/validate` với JSON `{"key":"..."}`.
- `GET /api/admin/keys` với header `x-admin-token`.
- `POST /api/admin/keys` với header `x-admin-token` và JSON `{"days":30}`.
- `PATCH /api/admin/keys/:id` với JSON `{"active":false}` để khóa key.

Lưu ý: đây là bản khung minh họa. Bản APK chỉ xác thực khi có mạng; không lưu trạng thái đăng nhập lâu dài để tránh dùng key đã bị thu hồi. Với sản phẩm công khai nên dùng HTTPS, rate limit, database thật và xác thực thiết bị/phân quyền phù hợp.

## Bảo mật bản 0.8
- Đã bỏ key chủ offline nhúng trong APK; không có key đăng nhập hợp lệ cố định trong mã ứng dụng.
- APK không tin cờ đăng nhập lưu cục bộ khi khởi động; người dùng phải xác thực lại với máy chủ.
- Bật R8 minify/obfuscation cho debug và release để làm khó việc đọc mã (không thể chống crack tuyệt đối).
- API xác thực có giới hạn thử cơ bản theo IP: 12 lần/phút mỗi tiến trình.
- Giao diện admin hỗ trợ khóa/mở khóa key theo ID.

Trước khi phát hành công khai: dùng HTTPS bắt buộc, database bền vững, giới hạn tốc độ bằng Redis nếu chạy nhiều instance, đăng nhập quản trị thật/MFA, nhật ký kiểm toán và không lưu key dạng rõ trong database. Không đưa `ADMIN_TOKEN` vào APK, HTML tĩnh công khai hoặc GitHub. R8 chỉ làm khó phân tích; mọi bí mật đặt trong APK đều có thể bị trích xuất bởi người đủ kỹ năng.


## Thay đổi trong bản kiểm tra v0.9
- Server lưu SHA-256 digest của key thay vì giữ key dạng rõ (các key cũ dạng rõ được chuyển đổi khi xác thực thành công). Key đầy đủ chỉ trả về đúng một lần lúc tạo.
- Ghi `keys.json` theo kiểu file tạm rồi đổi tên để giảm nguy cơ file JSON bị ghi dở.
- App có nút kiểm tra key trực tuyến và thử xác thực lại khi quay lại ứng dụng; nếu server xác nhận key đã khóa/hết hạn thì app quay về màn hình đăng nhập. Nếu mất mạng tạm thời, màn hình hiện tại được giữ nguyên nhưng không cấp đăng nhập mới offline.
- CẢNH BÁO: `keys.json` vẫn là lưu trữ file cục bộ, không bền vững trên một số nền tảng hosting miễn phí và không phù hợp cho sản phẩm công khai. Trước khi phát hành, hãy chuyển sang PostgreSQL bền vững và thêm ràng buộc thiết bị nếu cần.


## TSX ULTRA LOW graphics guidance
The Android app includes a guided low-graphics preset for Free Fire and Free Fire MAX. It provides per-game steps and launches the selected game. It does not patch game assets/configuration or import NVIDIA `.nip` profiles, which are for PC drivers. Android does not expose a general public API for forcing third-party games to use Roblox-like block graphics. Apply only the graphics options offered by the game itself.
