const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
app.use(express.json({ limit: "16kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
// Basic per-IP throttle for key guessing. Use a shared store (e.g. Redis) for multi-instance deployments.
const attempts = new Map();
function validateThrottle(req, res, next) {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const old = (attempts.get(ip) || []).filter(t => now - t < 60_000);
  if (old.length >= 12) return res.status(429).json({ valid: false, message: "Thử quá nhiều lần. Vui lòng đợi 1 phút." });
  old.push(now); attempts.set(ip, old);
  if (attempts.size > 5000) {
    for (const [k, v] of attempts) if (!v.length || now - v[v.length - 1] > 300_000) attempts.delete(k);
  }
  next();
}
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;
const DB = path.join(__dirname, "keys.json");
if (!ADMIN_TOKEN) {
  console.error("Set ADMIN_TOKEN to a long random secret before starting.");
  process.exit(1);
}
function readKeys() {
  try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return []; }
}
function writeKeys(keys) {
  const tmp = `${DB}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(keys, null, 2), { mode: 0o600 });
  fs.renameSync(tmp, DB);
}
function keyDigest(value) {
  return crypto.createHash("sha256").update(String(value), "utf8").digest("hex");
}
function digestMatches(candidate, stored) {
  if (typeof stored !== "string" || !/^[a-f0-9]{64}$/i.test(stored)) return false;
  const a = Buffer.from(keyDigest(candidate), "hex");
  const b = Buffer.from(stored, "hex");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function admin(req, res, next) {
  const token = req.get("x-admin-token");
  const a = Buffer.from(token || "");
  const b = Buffer.from(ADMIN_TOKEN);
  if (a.length !== b.length || !crypto.timingSafeEqual(a.length === b.length ? a : Buffer.alloc(b.length), b)) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}
app.post("/api/validate", validateThrottle, (req, res) => {
  const key = String(req.body?.key || "").trim();
  if (!key || key.length > 200) return res.status(400).json({ valid: false, message: "Key không hợp lệ." });
  const keys = readKeys();
  const item = keys.find(k => k.keyHash ? digestMatches(key, k.keyHash) : k.key === key);
  const now = Date.now();
  if (!item || !item.active || (item.expiresAt && now > item.expiresAt)) {
    return res.status(401).json({ valid: false, message: "Key sai, đã khóa hoặc hết hạn." });
  }
  item.lastUsedAt = now;
  // Upgrade legacy plaintext entries to a digest on first successful use.
  if (!item.keyHash) {
    item.keyHash = keyDigest(item.key);
    delete item.key;
  }
  writeKeys(keys);
  res.json({ valid: true, message: "Key hợp lệ." });
});
app.get("/api/admin/keys", admin, (_req, res) => {
  res.json(readKeys().map(({ key, keyHash, ...rest }) => ({ ...rest, key: "LAG-•••• (chỉ hiện khi tạo mới)" })));
});
app.post("/api/admin/keys", admin, (req, res) => {
  const days = Number(req.body?.days || 30);
  if (!Number.isInteger(days) || days < 1 || days > 3650) return res.status(400).json({ error: "days must be 1..3650" });
  const keys = readKeys();
  const key = "LAG-" + crypto.randomBytes(18).toString("hex").toUpperCase();
  const item = { id: crypto.randomUUID(), keyHash: keyDigest(key), active: true, createdAt: Date.now(), expiresAt: Date.now() + days * 86400000, lastUsedAt: null };
  keys.push(item); writeKeys(keys);
  // The full key is returned only at creation time; it is not stored in plaintext.
  res.status(201).json({ id: item.id, active: item.active, createdAt: item.createdAt, expiresAt: item.expiresAt, lastUsedAt: item.lastUsedAt, key });
});
app.patch("/api/admin/keys/:id", admin, (req, res) => {
  const keys = readKeys();
  const item = keys.find(k => k.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Not found" });
  if (typeof req.body?.active !== "boolean") return res.status(400).json({ error: "active must be boolean" });
  item.active = req.body.active; writeKeys(keys); res.json({ id: item.id, active: item.active });
});
app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`LagFix key server listening on ${PORT}`));
